export const headerImg = `
  w-[22px]
  mx-[10px]
`;