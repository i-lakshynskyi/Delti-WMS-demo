
export const footerContainer = "flex w-screen max-w-screen h-full items-center justify-around overflow-hidden bg-[#f5f5f5]  border-t border-[#d3d3d37a] pb-[15px]"
export const footerImgWrap = `
  flex
  flex-col
  items-center
  justify-center
  pb-[env(safe-area-inset-bottom)]
`;
export const footerImg = `w-[20px]`;
