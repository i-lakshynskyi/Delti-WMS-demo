
export const ZxingContainer = 'relative overflow-hidden rounded-xl';
export const ZxingOverlay = "absolute z-[10]"
export const ZxingImg = ''
export const ZxingVideo = 'rounded-xl p-1'